//
// Created by Sophia on 16.04.2020.
//

#ifndef DECOMPOSITION_BUS_MANAGER_H
#define DECOMPOSITION_BUS_MANAGER_H
#pragma once
#include <iostream>
#include <string>
#include <map>
#include <vector>
#include "responses.h"
using namespace std;

class BusManager {
public:
    void AddBus(const string& bus, const vector<string>& stops);
    BusesForStopResponse GetBusesForStop(const string& stop) const;
    StopsForBusResponse GetStopsForBus(const string& bus) const ;
    AllBusesResponse GetAllBuses() const ;

private:
    map<string, vector<string>> buses_to_stops;
    map<string, vector<string>> stops_to_buses;

};
#endif //DECOMPOSITION_BUS_MANAGER_H
