//
// Created by Sophia on 16.04.2020.
//

#ifndef DECOMPOSITION_QUERY_H
#define DECOMPOSITION_QUERY_H
#pragma once
#include <iostream>
#include <string>
#include <vector>
using namespace std;

enum class QueryType {
    NewBus,
    BusesForStop,
    StopsForBus,
    AllBuses
};

struct Query {
    QueryType type;
    string bus;
    string stop;
    vector<string> stops;
};
istream& operator >> (istream& is, Query& q);
#endif //DECOMPOSITION_QUERY_H
